const SPINURLRegex      = /vow.mlspin.com\/clients\/report.aspx/i;
const MATRIXURLRegex    = /stwmls.mlsmatrix.com\/Matrix\/Public\/Portal.aspx/i;